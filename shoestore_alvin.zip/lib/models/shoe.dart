class Shoe {
  final int id;
  final String name;
  final String brand;
  final int price;
  final String description;
  final String? imageUrl;

  Shoe({
    required this.id,
    required this.name,
    required this.brand,
    required this.price,
    required this.description,
    this.imageUrl,
  });

  factory Shoe.fromJson(Map<String, dynamic> j) => Shoe(
    id: int.parse(j["id"].toString()),
    name: j["name"] ?? "",
    brand: j["brand"] ?? "",
    price: int.parse(j["price"].toString()),
    description: j["description"] ?? "",
    imageUrl: j["image_url"],
  );
}
