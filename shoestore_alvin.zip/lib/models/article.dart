class Article {
  final int id;
  final String title;
  final String content;
  final String? imageUrl;
  final String createdAt;

  Article({
    required this.id,
    required this.title,
    required this.content,
    this.imageUrl,
    required this.createdAt,
  });

  factory Article.fromJson(Map<String, dynamic> j) => Article(
    id: int.parse(j["id"].toString()),
    title: j["title"] ?? "",
    content: j["content"] ?? "",
    imageUrl: j["image_url"],
    createdAt: j["created_at"]?.toString() ?? "",
  );
}
