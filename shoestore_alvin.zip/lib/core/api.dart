import 'package:dio/dio.dart';

class Api {
  static const String baseUrl = "https://alvin.bersama.cloud/api-alvin";

  final Dio dio = Dio(BaseOptions(
    baseUrl: baseUrl,
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 15),
    headers: {"Accept": "application/json"},
  ));
}
