import 'package:shared_preferences/shared_preferences.dart';

class Session {
  static const _kToken = "token";
  static const _kUserId = "user_id";
  static const _kName = "name";
  static const _kEmail = "email";

  static Future<void> saveLogin({
    required String token,
    required int userId,
    required String name,
    required String email,
  }) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kToken, token);
    await sp.setInt(_kUserId, userId);
    await sp.setString(_kName, name);
    await sp.setString(_kEmail, email);
  }

  static Future<void> logout() async {
    final sp = await SharedPreferences.getInstance();
    await sp.clear();
  }

  static Future<bool> isLoggedIn() async {
    final sp = await SharedPreferences.getInstance();
    return (sp.getString(_kToken) ?? "").isNotEmpty;
  }

  static Future<Map<String, dynamic>> user() async {
    final sp = await SharedPreferences.getInstance();
    return {
      "token": sp.getString(_kToken) ?? "",
      "user_id": sp.getInt(_kUserId) ?? 0,
      "name": sp.getString(_kName) ?? "",
      "email": sp.getString(_kEmail) ?? "",
    };
  }
}
