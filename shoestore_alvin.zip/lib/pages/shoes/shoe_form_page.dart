import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../../core/api.dart';
import '../../core/session.dart';

class ShoeFormPage extends StatefulWidget {
  final bool isEdit;
  final Map<String, dynamic>? editData;
  const ShoeFormPage({super.key, required this.isEdit, this.editData});

  @override
  State<ShoeFormPage> createState() => _ShoeFormPageState();
}

class _ShoeFormPageState extends State<ShoeFormPage> {
  final _formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final brand = TextEditingController();
  final price = TextEditingController();
  final desc = TextEditingController();
  final imageUrl = TextEditingController();
  bool loading = false;

  @override
  void initState() {
    super.initState();
    if (widget.isEdit && widget.editData != null) {
      name.text = widget.editData!["name"] ?? "";
      brand.text = widget.editData!["brand"] ?? "";
      price.text = (widget.editData!["price"] ?? "").toString();
      desc.text = widget.editData!["description"] ?? "";
      imageUrl.text = widget.editData!["image_url"] ?? "";
    }
  }

  @override
  void dispose() {
    name.dispose();
    brand.dispose();
    price.dispose();
    desc.dispose();
    imageUrl.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => loading = true);

    try {
      final api = Api();
      final u = await Session.user();

      final data = {
        "user_id": u["user_id"].toString(),
        "name": name.text.trim(),
        "brand": brand.text.trim(),
        "price": price.text.trim(),
        "description": desc.text.trim(),
        "image_url": imageUrl.text.trim(),
      };

      if (widget.isEdit) {
        data["id"] = widget.editData!["id"].toString();
        await api.dio.post(
          "/shoes/update.php",
          data: data,
          options: Options(contentType: Headers.formUrlEncodedContentType),
        );
      } else {
        await api.dio.post(
          "/shoes/create.php",
          data: data,
          options: Options(contentType: Headers.formUrlEncodedContentType),
        );
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(widget.isEdit ? "Berhasil update" : "Berhasil tambah")),
      );
      if (Navigator.canPop(context)) Navigator.pop(context);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal submit data")),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.isEdit ? "Edit Sepatu" : "Tambah Sepatu")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: name,
                decoration: const InputDecoration(labelText: "Nama Sepatu"),
                validator: (v) => (v == null || v.trim().isEmpty) ? "Wajib" : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: brand,
                decoration: const InputDecoration(labelText: "Brand"),
                validator: (v) => (v == null || v.trim().isEmpty) ? "Wajib" : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: price,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Harga"),
                validator: (v) => (v == null || v.trim().isEmpty) ? "Wajib" : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: desc,
                decoration: const InputDecoration(labelText: "Deskripsi"),
                minLines: 3,
                maxLines: null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: imageUrl,
                decoration: const InputDecoration(labelText: "Image URL (opsional)"),
              ),
              const SizedBox(height: 14),
              ElevatedButton(
                onPressed: loading ? null : submit,
                child: Text(loading ? "Loading..." : (widget.isEdit ? "Update" : "Create")),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
