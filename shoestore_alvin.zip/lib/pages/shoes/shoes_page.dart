import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../../core/api.dart';
import '../../models/shoe.dart';
import 'shoe_detail_page.dart';

class ShoesPage extends StatefulWidget {
  const ShoesPage({super.key});

  @override
  State<ShoesPage> createState() => _ShoesPageState();
}

class _ShoesPageState extends State<ShoesPage> {
  List<Shoe> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetch();
  }

  Future<void> fetch() async {
    setState(() => loading = true);
    try {
      final api = Api();
      final res = await api.dio.get("/shoes/list.php");
      final data = res.data;
      final list = (data["data"] as List).map((e) => Shoe.fromJson(e)).toList();
      setState(() => items = list);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal memuat katalog sepatu")),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    if (items.isEmpty) return const Center(child: Text("Data Kosong"));

    return RefreshIndicator(
      onRefresh: fetch,
      child: ListView.builder(
        itemCount: items.length,
        itemBuilder: (_, i) {
          final s = items[i];
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.black12),
            ),
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: s.imageUrl != null && s.imageUrl!.isNotEmpty
                    ? Image.network(s.imageUrl!, width: 56, height: 56, fit: BoxFit.cover)
                    : Image.asset("assets/shoe.png", width: 56, height: 56, fit: BoxFit.cover),
              ),
              title: Text("${s.name} (${s.brand})"),
              subtitle: Text("Rp ${s.price}\n${s.description}"),
              isThreeLine: true,
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ShoeDetailPage(id: s.id)),
                ).then((_) => fetch());
              },
            ),
          );
        },
      ),
    );
  }
}
