import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../../core/api.dart';
import '../../core/session.dart';
import 'shoe_form_page.dart';

class ShoeDetailPage extends StatefulWidget {
  final int id;
  const ShoeDetailPage({super.key, required this.id});

  @override
  State<ShoeDetailPage> createState() => _ShoeDetailPageState();
}

class _ShoeDetailPageState extends State<ShoeDetailPage> {
  Map<String, dynamic>? data;
  bool loading = true;

  Future<void> fetch() async {
    setState(() => loading = true);
    try {
      final api = Api();
      final res = await api.dio.get("/shoes/detail.php", queryParameters: {"id": widget.id});
      setState(() => data = res.data["data"]);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Gagal memuat detail")));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> del() async {
    try {
      final api = Api();
      await api.dio.post(
        "/shoes/delete.php",
        data: {"id": widget.id},
        options: Options(contentType: Headers.formUrlEncodedContentType),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Berhasil hapus")));
      Navigator.pop(context);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Gagal hapus")));
    }
  }

  @override
  void initState() {
    super.initState();
    fetch();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (data == null) return const Scaffold(body: Center(child: Text("Tidak ditemukan")));

    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail Sepatu"),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () {
              // Message (AlertDialog) poin a
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text("Message"),
                  content: const Text("Yakin ingin menghapus sepatu ini?"),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text("Batal")),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        del();
                      },
                      child: const Text("Hapus"),
                    ),
                  ],
                ),
              );
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(data!["name"] ?? "", style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text("Brand: ${data!["brand"]}"),
            Text("Harga: Rp ${data!["price"]}"),
            const SizedBox(height: 10),
            Text(data!["description"] ?? ""),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.edit),
                label: const Text("Edit"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ShoeFormPage(isEdit: true, editData: data),
                    ),
                  ).then((_) => fetch());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
