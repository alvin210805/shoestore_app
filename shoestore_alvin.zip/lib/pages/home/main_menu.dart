import 'package:flutter/material.dart';
import '../shoes/shoes_page.dart';
import '../shoes/shoe_form_page.dart';
import '../articles/articles_page.dart';
import '../profile/profile_page.dart';
import '../about/about_page.dart';

class MainMenu extends StatefulWidget {
  const MainMenu({super.key});

  @override
  State<MainMenu> createState() => _MainMenuState();
}

class _MainMenuState extends State<MainMenu> {
  int idx = 0;

  final pages = const [
    ShoesPage(),
    ShoeFormPage(isEdit: false),
    ArticlesPage(),
    ProfilePage(),
    AboutPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Katalog Sepatu Alvin")),
      body: pages[idx],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: idx,
        onTap: (i) => setState(() => idx = i),
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.store), label: "Katalog"),
          BottomNavigationBarItem(icon: Icon(Icons.add_box), label: "Tambah"),
          BottomNavigationBarItem(icon: Icon(Icons.article), label: "Artikel"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: "Tentang"),
        ],
      ),
    );
  }
}
