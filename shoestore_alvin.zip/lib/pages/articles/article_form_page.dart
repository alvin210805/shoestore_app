import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import '../../core/api.dart';
import '../../core/session.dart';

class ArticleFormPage extends StatefulWidget {
  final bool isEdit;
  final Map<String, dynamic>? editData;

  const ArticleFormPage({super.key, required this.isEdit, this.editData});

  @override
  State<ArticleFormPage> createState() => _ArticleFormPageState();
}

class _ArticleFormPageState extends State<ArticleFormPage> {
  final _formKey = GlobalKey<FormState>();

  final title = TextEditingController();
  final content = TextEditingController();
  final imageUrl = TextEditingController();

  bool loading = false;

  @override
  void initState() {
    super.initState();
    if (widget.isEdit && widget.editData != null) {
      title.text = widget.editData!["title"]?.toString() ?? "";
      content.text = widget.editData!["content"]?.toString() ?? "";
      imageUrl.text = widget.editData!["image_url"]?.toString() ?? "";
    }
  }

  @override
  void dispose() {
    title.dispose();
    content.dispose();
    imageUrl.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => loading = true);

    try {
      final api = Api();
      final u = await Session.user();

      final data = {
        "user_id": u["user_id"].toString(),
        "title": title.text.trim(),
        "content": content.text.trim(),
        "image_url": imageUrl.text.trim(),
      };

      if (widget.isEdit) {
        data["id"] = widget.editData!["id"].toString();
        await api.dio.post(
          "/articles/update.php",
          data: data,
          options: Options(contentType: Headers.formUrlEncodedContentType),
        );
      } else {
        await api.dio.post(
          "/articles/create.php",
          data: data,
          options: Options(contentType: Headers.formUrlEncodedContentType),
        );
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.isEdit ? "Artikel berhasil diupdate" : "Artikel berhasil ditambah"),
        ),
      );
      Navigator.pop(context);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal submit artikel")),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isEdit ? "Edit Artikel" : "Tambah Artikel"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.black12),
            ),
            child: ListView(
              children: [
                TextFormField(
                  controller: title,
                  decoration: const InputDecoration(
                    labelText: "Judul Artikel",
                    prefixIcon: Icon(Icons.title),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? "Judul wajib" : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: content,
                  minLines: 5,
                  maxLines: null,
                  decoration: const InputDecoration(
                    labelText: "Isi Artikel",
                    alignLabelWithHint: true,
                    prefixIcon: Icon(Icons.article),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? "Konten wajib" : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: imageUrl,
                  decoration: const InputDecoration(
                    labelText: "Image URL (opsional)",
                    prefixIcon: Icon(Icons.image),
                  ),
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: loading ? null : submit,
                  icon: const Icon(Icons.save),
                  label: Text(loading ? "Loading..." : (widget.isEdit ? "Update" : "Create")),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
