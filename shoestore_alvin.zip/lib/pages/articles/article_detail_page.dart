import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import '../../core/api.dart';
import 'article_form_page.dart';

class ArticleDetailPage extends StatefulWidget {
  final int id;
  const ArticleDetailPage({super.key, required this.id});

  @override
  State<ArticleDetailPage> createState() => _ArticleDetailPageState();
}

class _ArticleDetailPageState extends State<ArticleDetailPage> {
  bool loading = true;
  Map<String, dynamic>? data;

  @override
  void initState() {
    super.initState();
    fetch();
  }

  Future<void> fetch() async {
    setState(() => loading = true);
    try {
      final api = Api();
      final res = await api.dio.get(
        "/articles/detail.php",
        queryParameters: {"id": widget.id},
      );
      setState(() => data = res.data["data"]);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal memuat detail artikel")),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> del() async {
    try {
      final api = Api();
      await api.dio.post(
        "/articles/delete.php",
        data: {"id": widget.id},
        options: Options(contentType: Headers.formUrlEncodedContentType),
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Artikel berhasil dihapus")),
      );
      Navigator.pop(context);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal menghapus artikel")),
      );
    }
  }

  void confirmDelete() {
    // message (AlertDialog) poin a
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Message"),
        content: const Text("Yakin ingin menghapus artikel ini?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Batal"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              del();
            },
            child: const Text("Hapus"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (data == null) {
      return const Scaffold(
        body: Center(child: Text("Tidak ditemukan")),
      );
    }

    final title = data!["title"]?.toString() ?? "";
    final content = data!["content"]?.toString() ?? "";
    final imageUrl = data!["image_url"]?.toString() ?? "";

    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail Artikel"),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: confirmDelete,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            if (imageUrl.isNotEmpty)
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Image.network(imageUrl, height: 200, fit: BoxFit.cover),
              )
            else
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Image.asset("assets/shoe.png", height: 200, fit: BoxFit.cover),
              ),
            const SizedBox(height: 14),
            Text(
              title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(content),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.edit),
              label: const Text("Edit Artikel"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ArticleFormPage(isEdit: true, editData: data),
                  ),
                ).then((_) => fetch());
              },
            ),
          ],
        ),
      ),
    );
  }
}
