import 'package:flutter/material.dart';
import '../../core/api.dart';
import '../../models/article.dart';
import 'article_detail_page.dart';
import 'article_form_page.dart';

class ArticlesPage extends StatefulWidget {
  const ArticlesPage({super.key});

  @override
  State<ArticlesPage> createState() => _ArticlesPageState();
}

class _ArticlesPageState extends State<ArticlesPage> {
  bool loading = true;
  List<Article> items = [];

  @override
  void initState() {
    super.initState();
    fetch();
  }

  Future<void> fetch() async {
    setState(() => loading = true);
    try {
      final api = Api();
      final res = await api.dio.get("/articles/list.php");
      final data = res.data;

      final list = (data["data"] as List)
          .map((e) => Article.fromJson(e as Map<String, dynamic>))
          .toList();

      setState(() => items = list);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Gagal memuat artikel")),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());

    return RefreshIndicator(
      onRefresh: fetch,
      child: ListView.builder(
        itemCount: items.length + 1,
        itemBuilder: (_, i) {
          // Baris pertama = tombol tambah (biar gampang akses)
          if (i == 0) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
              child: ElevatedButton.icon(
                icon: const Icon(Icons.add),
                label: const Text("Tambah Artikel"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ArticleFormPage(isEdit: false),
                    ),
                  ).then((_) => fetch());
                },
              ),
            );
          }

          final a = items[i - 1];

          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.black12),
            ),
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: a.imageUrl != null && a.imageUrl!.isNotEmpty
                    ? Image.network(a.imageUrl!,
                    width: 56, height: 56, fit: BoxFit.cover)
                    : Image.asset("assets/shoe.png",
                    width: 56, height: 56, fit: BoxFit.cover),
              ),
              title: Text(
                a.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle: Text(
                a.content,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ArticleDetailPage(id: a.id)),
                ).then((_) => fetch());
              },
            ),
          );
        },
      ),
    );
  }
}
