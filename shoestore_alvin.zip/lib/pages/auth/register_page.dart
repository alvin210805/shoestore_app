import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../../core/api.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _loading = false;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);

    try {
      final api = Api();
      final res = await api.dio.post(
        "/auth/register.php",
        data: {
          "name": _name.text.trim(),
          "email": _email.text.trim(),
          "password": _pass.text,
        },
        options: Options(contentType: Headers.formUrlEncodedContentType),
      );

      final data = res.data;
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(data["message"] ?? "Register done")),
      );

      if (data["success"] == true) {
        Navigator.pop(context); // balik ke login
      }
    } catch (e) {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text("Message"),
          content: Text("Terjadi error: $e"),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK")),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Register")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: "Nama"),
                validator: (v) => (v == null || v.trim().isEmpty) ? "Nama wajib" : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _email,
                decoration: const InputDecoration(labelText: "Email"),
                validator: (v) => (v == null || v.trim().isEmpty) ? "Email wajib" : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _pass,
                obscureText: true,
                decoration: const InputDecoration(labelText: "Password"),
                validator: (v) => (v == null || v.isEmpty) ? "Password wajib" : null,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _loading ? null : _register,
                child: Text(_loading ? "Loading..." : "Register"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
