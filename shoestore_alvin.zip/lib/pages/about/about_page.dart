import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // IMAGE (shoe.png)
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.asset(
              "assets/shoe.png",
              width: 200,
              height: 200,
              fit: BoxFit.cover,
            ),
          ),

          const SizedBox(height: 20),

          // JUDUL APLIKASI
          const Text(
            "Katalog Sepatu Alvin",
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 10),

          // DESKRIPSI
          const Text(
            "Aplikasi mobile berbasis Flutter untuk menampilkan "
                "katalog sepatu dan artikel, dilengkapi dengan fitur "
                "Login, Register, CRUD Sepatu, CRUD Artikel, "
                "SharedPreferences, dan API PHP.",
            style: TextStyle(fontSize: 16),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 20),

          // INFO TAMBAHAN (opsional)
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.black12),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("👤 Developer: Alvin"),
                SizedBox(height: 6),
                Text("📱 Platform: Flutter (Android)"),
                SizedBox(height: 6),
                Text("🌐 Backend: PHP & MySQL"),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
